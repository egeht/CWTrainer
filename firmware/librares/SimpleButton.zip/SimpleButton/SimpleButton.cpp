#include "SimpleButton.h"

void SimpleButton::begin(uint8_t button) {
  btn = button;
  state = 0xFFFF; // Сразу ставим состояние "отпущена"
  pinMode(btn, INPUT_PULLUP);
}

bool SimpleButton::debounce() {
  state = (state << 1) | digitalRead(btn) | 0x8000;
  return (state == 0xC000);
}

bool SimpleButton::onRelease() {
  return (state == 0xBFFF);
}

bool SimpleButton::isIdle() {
  return (state == 0xFFFF);
}

bool SimpleButton::isHeld() {
  return (state == 0x8000);
}
