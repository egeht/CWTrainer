#ifndef SimpleButton_h
#define SimpleButton_h

#include "Arduino.h"

class SimpleButton {
  private:
    uint8_t btn;
    uint16_t state;
    
  public:
    void begin(uint8_t button);
    bool debounce();
    bool onRelease();
    bool isIdle();
    bool isHeld();
};

#endif
